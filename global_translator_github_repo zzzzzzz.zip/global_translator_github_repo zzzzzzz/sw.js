const APP_CACHE = 'global-hybrid-translator-shell-v3.2.0';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './version.json',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(APP_CACHE).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          // Delete old app shells ONLY — never delete user's downloaded Offline AI models!
          if (key.startsWith('global-hybrid-translator-shell-') && key !== APP_CACHE) {
            return caches.delete(key);
          }
          return Promise.resolve();
        })
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Cache Transformers.js & Tesseract.js runtime files for offline boot
  if (url.hostname.includes('cdn.jsdelivr.net') && (url.pathname.includes('transformers') || url.pathname.includes('tesseract'))) {
    event.respondWith(
      caches.open('transformers-runtime-v2').then((cache) =>
        cache.match(event.request).then((cached) => {
          if (cached) return cached;
          return fetch(event.request).then((resp) => {
            if (resp && resp.ok) cache.put(event.request, resp.clone());
            return resp;
          });
        })
      )
    );
    return;
  }

  // NETWORK-FIRST for same-origin App Shell so GitHub updates auto-refresh on every phone!
  if (url.origin === self.location.origin && event.request.method === 'GET') {
    event.respondWith(
      fetch(event.request, { cache: 'no-cache' })
        .then((resp) => {
          if (resp && resp.ok) {
            const copy = resp.clone();
            caches.open(APP_CACHE).then((cache) => cache.put(event.request, copy));
          }
          return resp;
        })
        .catch(() => caches.match(event.request, { ignoreSearch: true }))
    );
  }
});
